# 🎬 MovieFlix AI — Movie Prediction & Netflix-Style Recommendation

A complete portfolio-ready machine-learning web application built around a **5,000-movie dataset**.

## What it includes
- React + Vite frontend
- Tailwind CSS glassmorphism / high-contrast UI
- FastAPI REST API
- Random Forest regression for movie-rating prediction
- TF-IDF + cosine similarity recommendation engine
- 5,000-row movie dataset included
- Search + genre filters
- Netflix-style movie catalog
- Movie detail pages and “Because you watched this” recommendations
- Analytics dashboard
- Docker Compose
- Health endpoint and clean API structure
- Demo UI artwork in `docs/demo-dashboard.svg`

## Run with Docker
```bash
docker compose up --build
```
Open:
- Frontend: http://localhost:5173
- API: http://localhost:8000/docs

## Run manually

### Backend
```bash
cd backend
python -m venv venv
# Windows PowerShell:
.env\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## ML
The prediction model uses:
`year`, `runtime`, `budget_million`, `votes`, `popularity`, `revenue_million`

The recommendation engine combines movie title, genre, subgenre, director and cast using TF-IDF vectors and cosine similarity.

> Dataset is generated for demonstration/academic portfolio use. It is intentionally packaged locally so the project works without an external API key.
