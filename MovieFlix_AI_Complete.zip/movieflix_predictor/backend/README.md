# MovieFlix API
Interactive docs are available at `/docs`.

Endpoints:
- `GET /api/health`
- `GET /api/movies?q=&genre=&limit=`
- `GET /api/movie/{id}`
- `GET /api/recommend/{id}`
- `POST /api/predict`
- `GET /api/stats`
