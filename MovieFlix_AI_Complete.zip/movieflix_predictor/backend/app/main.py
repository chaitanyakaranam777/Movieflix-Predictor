
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer

DATA = Path(__file__).resolve().parent.parent / "data" / "movies.csv"
df = pd.read_csv(DATA)

app = FastAPI(title="MovieFlix Prediction API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

FEATURES=["year","runtime","budget_million","votes","popularity","revenue_million"]
X=df[FEATURES].fillna(0)
y=df["rating"]
model=RandomForestRegressor(n_estimators=180, random_state=42, n_jobs=-1, max_depth=16)
model.fit(X,y)

text=df["title"].fillna("")+" "+df["genre"].fillna("")+" "+df["subgenre"].fillna("")+" "+df["director"].fillna("")+" "+df["cast"].fillna("")
tfidf=TfidfVectorizer(stop_words="english", ngram_range=(1,2), max_features=12000)
matrix=tfidf.fit_transform(text)

class PredictionInput(BaseModel):
    year:int
    runtime:int
    budget_million:float
    votes:int
    popularity:float
    revenue_million:float

@app.get("/api/health")
def health():
    return {"status":"ok","movies":len(df),"model":"RandomForestRegressor"}

@app.get("/api/movies")
def movies(q:str="", genre:str="", limit:int=24, offset:int=0):
    x=df
    if q:
        x=x[x["title"].str.contains(q,case=False,na=False)]
    if genre and genre!="All":
        x=x[x["genre"].str.lower()==genre.lower()]
    x=x.sort_values(["popularity","rating"],ascending=False)
    return x.iloc[offset:offset+limit].to_dict("records")

@app.get("/api/movie/{movie_id}")
def movie(movie_id:int):
    r=df[df.id==movie_id]
    if r.empty: raise HTTPException(404,"Movie not found")
    return r.iloc[0].to_dict()

@app.get("/api/recommend/{movie_id}")
def recommend(movie_id:int, limit:int=8):
    idx=df.index[df.id==movie_id]
    if len(idx)==0: raise HTTPException(404,"Movie not found")
    i=idx[0]
    scores=cosine_similarity(matrix[i],matrix).flatten()
    order=scores.argsort()[::-1]
    order=[j for j in order if j!=i][:limit]
    out=df.iloc[order].copy()
    out["match"]=np.round(scores[order]*100,1)
    return out.to_dict("records")

@app.post("/api/predict")
def predict(p:PredictionInput):
    vals=np.array([[p.year,p.runtime,p.budget_million,p.votes,p.popularity,p.revenue_million]])
    pred=float(np.clip(model.predict(vals)[0],0,10))
    confidence=float(np.clip(70+abs(pred-5)*7,70,96))
    label="Hit potential" if pred>=7.2 else ("Promising" if pred>=6.2 else "Mixed")
    return {"predicted_rating":round(pred,2),"confidence":round(confidence,1),"verdict":label}

@app.get("/api/stats")
def stats():
    return {
      "movies":len(df),
      "avg_rating":round(float(df.rating.mean()),2),
      "avg_popularity":round(float(df.popularity.mean()),2),
      "genres":df.genre.value_counts().to_dict(),
      "platforms":df.platform.value_counts().to_dict(),
      "top":df.sort_values("popularity",ascending=False).head(6).to_dict("records")
    }
